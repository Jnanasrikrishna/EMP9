package com.company.assesment.configuration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Applicatoin {
	 public static void main(String[] args) {
	        SpringApplication.run(Applicatoin.class, args);
	    }
}
